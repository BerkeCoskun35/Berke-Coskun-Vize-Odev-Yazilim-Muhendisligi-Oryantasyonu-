import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.println("Bir sayı giriniz: ");
        int sayi = scan.nextInt();
        int a1 = 0, a2 = 1;
        System.out.println(sayi + " sayısının fibonacci sayıları: ");

        for(int i = 1; i <=sayi; ++i){
            System.out.println(a1);
            int toplam = a1 + a2;
            a1 = a2;
            a2 = toplam;
        }
    }
}
