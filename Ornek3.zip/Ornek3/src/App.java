public class App {
    public static void main(String[] args) throws Exception {
        int sayi = 25, bolen = 3;
        int bolum = sayi / bolen;
        int kalan = sayi % bolen;
        System.out.println("İşlem: " +sayi+"/"+bolen);
        System.out.println("Bölüm: "+ bolum);
        System.out.println("Kalan: " +kalan);
    }
}
