import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.println("Öğrencinin Notunu Giriniz: ");
        int not = scan.nextInt();
        if(not<50){
            System.out.println("Öğrencinin notu 50'den düşük olduğu için kaldı (1)");
        }
        else if (not<60){
            System.out.println("Öğrencinin notu 50 ile 60 arasında olduğundan geçti (2)");
        }
        else if (not<70){
            System.out.println("Öğrencinin notu 60 ile 70 arasında olduğundan geçti (3)");
        }
        else if (not<85){
            System.out.println("Öğrencinin notu 70 ile 85 arasında olduğundan geçti (4)");
        }
        else if (not<=100){
            System.out.println("Öğrencinin notu 85 ile 100 arasında olduğundan geçti (5)");
        }
        else{
            System.out.println("Geçerli bir öğrenci notu giriniz!");
        }
    }
}
