public class App {
    public static void main(String[] args) throws Exception {
       int toplam = 0;
       for(int i = 1; i<=100; i++){
            toplam = toplam + i;
       }
       System.out.println("1'den 100'e kadar olan sayıların toplamının sonucu: " + toplam);
    }
}
