import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.println("Faktöriyelini hesaplanmasını istediğiniz sayıyı giriniz: ");
        int sayi = scan.nextInt();
        int sayac = sayi;
        int faktoriyel = 1;
        while(sayac>1){
            faktoriyel = faktoriyel * sayac;
            sayac--;
        }
        System.out.println("Girilen sayının faktöriyeli: " + faktoriyel);
    }
}
