public class App {
    public static void main(String[] args) throws Exception {
        int a = 10, b = 20;
        int sonuc = a+b;
        System.out.println("Toplama işleminin Sonucu:" + sonuc);
    }
}
