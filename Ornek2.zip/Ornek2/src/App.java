import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.println("Birinci Sayıyı Giriniz: ");
        int sayi1 = scan.nextInt();
        System.out.println("İkinci Sayıyı Giriniz: ");
        int sayi2 = scan.nextInt();
        int toplam = sayi1+sayi2;
        System.out.println("Toplama işleminin sonucu: " + toplam);
    }
}
