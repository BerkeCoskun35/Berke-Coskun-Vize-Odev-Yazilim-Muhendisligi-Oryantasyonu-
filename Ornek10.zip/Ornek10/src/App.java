import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.print("Öğrencinin vize notunu giriniz: ");
        double vize = scan.nextDouble();
        System.out.print("Öğrencinin final notunu giriniz: ");
        double Final = scan.nextDouble();

        double sonucVize = vize * 0.4;
        double sonucFinal = Final * 0.6;

        double Sonuc = sonucVize + sonucFinal;

        System.out.println("Öğrencinin not ortalaması: " + Sonuc);

    }
}
