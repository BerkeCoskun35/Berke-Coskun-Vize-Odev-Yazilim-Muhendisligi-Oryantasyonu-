import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.println("Bir sayı giriniz:");
        int sayi = scan.nextInt();
        if(sayi==0){
            System.out.println("Girilen sayı sıfırdır.");
        }
        else if(sayi<0){
            System.out.println("Girilen sayı negatif bir sayıdır.");
        }
        else{
            System.out.println("Girilen sayı pozitif bir sayıdır.");
        }
    }
}
