import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.print("Bir sayı giriniz: ");
        double sayi = scan.nextDouble();
        double sonuc = sayi % 2.0;
        if(sonuc == 1){
            System.out.print("Girilen sayı tektir.");
        }
        else{
            System.out.print("Girilen sayı çifttir.");
        }
    }
}
